from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models.doacao import Doacao
from app.models.medicamento import Medicamento
from app.database import db
from app.utils.log_helper import registrar_log

donation_bp = Blueprint('donation', __name__)


@donation_bp.route('/doacoes', methods=['GET', 'POST'])
@login_required
def nova_doacao():
    if request.method == 'POST':
        med_id = request.form.get('medicamento_id')
        quantidade_str = request.form.get('quantidade', '0')

        try:
            qtd = int(quantidade_str)
            if qtd <= 0:
                flash('A quantidade deve ser maior que zero.', 'danger')
                return redirect(url_for('donation.nova_doacao'))
        except ValueError:
            flash('Quantidade inválida.', 'danger')
            return redirect(url_for('donation.nova_doacao'))

        medicamento = db.session.get(Medicamento, med_id)

        if not medicamento:
            flash('Medicamento não encontrado.', 'danger')
            return redirect(url_for('donation.nova_doacao'))

        if medicamento.quantidade < qtd:
            flash('Quantidade insuficiente no estoque.', 'danger')
            return redirect(url_for('donation.nova_doacao'))

        try:
            medicamento.quantidade -= qtd
            registro = Doacao(
                usuario_id=current_user.id,
                medicamento_id=medicamento.id,
                quantidade=qtd
            )
            db.session.add(registro)
            db.session.commit()
            registrar_log(
                'Doação Registrada',
                f'{qtd} un. de "{medicamento.nome}" (Lote {medicamento.lote}) doadas por "{current_user.nome}"'
            )
            flash('Doação registrada com sucesso!', 'success')
        except Exception:
            db.session.rollback()
            flash('Erro ao registrar doação. Tente novamente.', 'danger')

        return redirect(url_for('donation.nova_doacao'))

    medicamentos = Medicamento.query.filter(Medicamento.quantidade > 0).all()
    doacoes = Doacao.query.order_by(Doacao.data_doacao.desc()).all()
    return render_template('doacoes.html', medicamentos=medicamentos, doacoes=doacoes)
