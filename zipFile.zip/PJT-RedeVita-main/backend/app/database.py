from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate

db = SQLAlchemy()
migrate = Migrate()

# ---------------------------------------------------------------------------
# Seed data: ANVISA reference medications (Portaria 344 + tarjas)
# ---------------------------------------------------------------------------
_REFERENCIA_ANVISA = [
    # (nome_comercial, registro_ms, principio_ativo, tarja, uso_continuo, tipo_receita)
    ('Dipirona 500mg',        '1.0783.0244.001', 'Dipirona Sódica',                'Sem Tarja',    False, 'Receita Simples'),
    ('Paracetamol 500mg',     '1.0228.0025.001', 'Paracetamol',                    'Sem Tarja',    False, 'Receita Simples'),
    ('Ibuprofeno 600mg',      '1.0244.0120.001', 'Ibuprofeno',                     'Tarja Vermelha', False, 'Receita de Controle Especial (Branca)'),
    ('Amoxicilina 500mg',     '1.0558.0064.001', 'Amoxicilina Tri-Hidratada',      'Tarja Vermelha', False, 'Receita de Controle Especial (Branca)'),
    ('Atenolol 25mg',         '1.0228.0038.001', 'Atenolol',                       'Tarja Vermelha', True,  'Receita de Controle Especial (Branca)'),
    ('Losartana 50mg',        '1.0558.0512.001', 'Losartana Potássica',            'Tarja Vermelha', True,  'Receita de Controle Especial (Branca)'),
    ('Metformina 850mg',      '1.0228.0132.001', 'Cloridrato de Metformina',       'Tarja Vermelha', True,  'Receita de Controle Especial (Branca)'),
    ('Omeprazol 20mg',        '1.0558.0380.001', 'Omeprazol',                      'Tarja Vermelha', True,  'Receita de Controle Especial (Branca)'),
    ('Sinvastatina 20mg',     '1.0244.0244.001', 'Sinvastatina',                   'Tarja Vermelha', True,  'Receita de Controle Especial (Branca)'),
    ('Amitriptilina 25mg',    '1.0228.0011.001', 'Cloridrato de Amitriptilina',    'Tarja Vermelha', True,  'Receita de Controle Especial (Branca)'),
    ('Levotiroxina 50mcg',    '1.0228.0124.001', 'Levotiroxina Sódica',            'Tarja Vermelha', True,  'Receita de Controle Especial (Branca)'),
    ('Captopril 25mg',        '1.0228.0047.001', 'Captopril',                      'Tarja Vermelha', True,  'Receita de Controle Especial (Branca)'),
    ('Prednisona 20mg',       '1.0244.0185.001', 'Prednisona',                     'Tarja Vermelha', False, 'Receita de Controle Especial (Branca)'),
    ('Azitromicina 500mg',    '1.0244.0281.001', 'Azitromicina Di-Hidratada',      'Tarja Vermelha', False, 'Receita de Controle Especial (Branca)'),
    ('Clonazepam 2mg',        '1.0244.0088.001', 'Clonazepam',                     'Portaria 344',  True,  "Receita 'B' Especial (Azul)"),
    ('Alprazolam 0,5mg',      '1.0244.0021.001', 'Alprazolam',                     'Portaria 344',  True,  "Receita 'B' Especial (Azul)"),
    ('Diazepam 10mg',         '1.0244.0096.001', 'Diazepam',                       'Portaria 344',  False, "Receita 'B' Especial (Azul)"),
    ('Metilfenidato 10mg',    '1.0244.0151.001', 'Cloridrato de Metilfenidato',    'Portaria 344',  True,  "Receita 'A' (Amarela)"),
    ('Morfina 10mg/mL',       '1.0244.0162.001', 'Sulfato de Morfina',             'Portaria 344',  False, "Receita 'A' (Amarela)"),
    ('Tramadol 100mg',        '1.0244.0232.001', 'Cloridrato de Tramadol',         'Portaria 344',  False, "Receita 'B' Especial (Azul)"),
]


def init_db(app):
    db.init_app(app)
    migrate.init_app(app, db)


def aplicar_migracoes_manuais(app):
    """Aplica colunas novas em tabelas existentes (seguro para SQLite e PostgreSQL)."""
    from sqlalchemy import text, inspect
    with app.app_context():
        with db.engine.connect() as conn:
            inspector = inspect(conn)
            _add_column_if_missing(conn, inspector, 'usuarios',    'ativo',           'BOOLEAN DEFAULT TRUE')
            _add_column_if_missing(conn, inspector, 'farmacias',   'razao_social',    'VARCHAR(200)')
            _add_column_if_missing(conn, inspector, 'receitas',    'status',          "VARCHAR(20) DEFAULT 'pendente'")
            _add_column_if_missing(conn, inspector, 'receitas',    'dispensada_em',   'TIMESTAMP')
            _add_column_if_missing(conn, inspector, 'receitas',    'dispensada_por_id', 'INTEGER')
            _add_column_if_missing(conn, inspector, 'receitas',    'tipo_receita',    'VARCHAR(60)')
            _add_column_if_missing(conn, inspector, 'medicamentos', 'tarja',          "VARCHAR(30) DEFAULT 'Sem Tarja'")
            _add_column_if_missing(conn, inspector, 'medicamentos', 'principio_ativo', 'VARCHAR(120)')
            _add_column_if_missing(conn, inspector, 'medicamentos', 'uso_continuo',   'BOOLEAN DEFAULT FALSE')
            _add_column_if_missing(conn, inspector, 'medicamentos', 'referencia_id',  'INTEGER')
            conn.commit()


def seed_medicamentos_referencia(app):
    """Popula a tabela de referência ANVISA se ainda estiver vazia."""
    from app.models.medicamento_referencia import MedicamentoReferencia
    with app.app_context():
        if MedicamentoReferencia.query.first() is not None:
            return
        for nome, reg, pa, tarja, continuo, tipo in _REFERENCIA_ANVISA:
            ref = MedicamentoReferencia(
                nome_comercial=nome,
                registro_ms=reg,
                principio_ativo=pa,
                tarja=tarja,
                uso_continuo=continuo,
                tipo_receita=tipo,
            )
            db.session.add(ref)
        db.session.commit()


def _add_column_if_missing(conn, inspector, table, column, col_type):
    from sqlalchemy import text
    tables = inspector.get_table_names()
    if table not in tables:
        return
    cols = [c['name'] for c in inspector.get_columns(table)]
    if column not in cols:
        conn.execute(text(f'ALTER TABLE {table} ADD COLUMN {column} {col_type}'))
