import os
import logging
from datetime import date, timedelta
from app.database import db
from app.models.medicamento import Medicamento

logger = logging.getLogger(__name__)


def _get_twilio_client():
    from twilio.rest import Client
    sid = os.environ.get('TWILIO_ACCOUNT_SID', '').strip()
    token = os.environ.get('TWILIO_AUTH_TOKEN', '').strip()
    if not sid or not token:
        raise RuntimeError('Credenciais Twilio não configuradas (TWILIO_ACCOUNT_SID / TWILIO_AUTH_TOKEN).')
    return Client(sid, token)


def _numero_from() -> str:
    n = os.environ.get('TWILIO_FROM_NUMBER', '').strip()
    if not n:
        raise RuntimeError('TWILIO_FROM_NUMBER não configurado.')
    return n


def medicamentos_criticos(dias: int = 60):
    hoje = date.today()
    limite = hoje + timedelta(days=dias)
    return (
        Medicamento.query
        .filter(Medicamento.data_validade <= limite)
        .order_by(Medicamento.data_validade.asc())
        .all()
    )


def _montar_mensagem(meds, dias: int) -> str:
    hoje = date.today()
    linhas = [f'*RedeVita — Alerta de Validade* ({hoje.strftime("%d/%m/%Y")})\n']
    for m in meds:
        restantes = (m.data_validade - hoje).days
        if restantes < 0:
            status = 'VENCIDO'
        elif restantes == 0:
            status = 'Vence HOJE'
        else:
            status = f'Vence em {restantes} dia(s)'
        linhas.append(f'• {m.nome} (Lote {m.lote}) — {status} — {m.quantidade} un.')
    linhas.append(f'\nTotal: {len(meds)} medicamento(s) nos próximos {dias} dias.')
    return '\n'.join(linhas)


def enviar_sms(telefone: str, dias: int = 60) -> dict:
    meds = medicamentos_criticos(dias)
    if not meds:
        return {'ok': True, 'mensagem': 'Nenhum medicamento crítico encontrado.', 'enviado': False}
    mensagem = _montar_mensagem(meds, dias)
    try:
        client = _get_twilio_client()
        msg = client.messages.create(
            body=mensagem,
            from_=_numero_from(),
            to=telefone
        )
        logger.info('SMS enviado para %s — SID %s', telefone, msg.sid)
        return {'ok': True, 'mensagem': f'SMS enviado ({len(meds)} med(s)).', 'sid': msg.sid, 'enviado': True}
    except RuntimeError as e:
        return {'ok': False, 'mensagem': str(e), 'enviado': False}
    except Exception as e:
        logger.error('Erro ao enviar SMS: %s', e)
        return {'ok': False, 'mensagem': f'Erro ao enviar SMS: {e}', 'enviado': False}


def enviar_whatsapp(telefone: str, dias: int = 60) -> dict:
    meds = medicamentos_criticos(dias)
    if not meds:
        return {'ok': True, 'mensagem': 'Nenhum medicamento crítico encontrado.', 'enviado': False}
    mensagem = _montar_mensagem(meds, dias)
    try:
        client = _get_twilio_client()
        numero_from = _numero_from()
        from_wa = f'whatsapp:{numero_from}' if not numero_from.startswith('whatsapp:') else numero_from
        to_wa = f'whatsapp:{telefone}' if not telefone.startswith('whatsapp:') else telefone
        msg = client.messages.create(
            body=mensagem,
            from_=from_wa,
            to=to_wa
        )
        logger.info('WhatsApp enviado para %s — SID %s', telefone, msg.sid)
        return {'ok': True, 'mensagem': f'WhatsApp enviado ({len(meds)} med(s)).', 'sid': msg.sid, 'enviado': True}
    except RuntimeError as e:
        return {'ok': False, 'mensagem': str(e), 'enviado': False}
    except Exception as e:
        logger.error('Erro ao enviar WhatsApp: %s', e)
        return {'ok': False, 'mensagem': f'Erro ao enviar WhatsApp: {e}', 'enviado': False}
