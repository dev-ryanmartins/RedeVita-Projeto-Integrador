import os
from datetime import date
from flask import Blueprint, render_template, request, jsonify, flash, redirect, url_for
from flask_login import login_required
from app.core.decorators import admin_required
from app.utils.notificacoes import medicamentos_criticos, enviar_sms, enviar_whatsapp
from app.utils.log_helper import registrar_log

notificacoes_bp = Blueprint('notificacoes', __name__)


@notificacoes_bp.route('/notificacoes')
@login_required
@admin_required
def painel():
    twilio_ok = bool(
        os.environ.get('TWILIO_ACCOUNT_SID') and
        os.environ.get('TWILIO_AUTH_TOKEN') and
        os.environ.get('TWILIO_FROM_NUMBER')
    )
    meds_30 = medicamentos_criticos(30)
    meds_60 = medicamentos_criticos(60)
    hoje = date.today()
    return render_template(
        'notificacoes.html',
        twilio_ok=twilio_ok,
        meds_30=meds_30,
        meds_60=meds_60,
        hoje=hoje,
    )


@notificacoes_bp.route('/notificacoes/enviar', methods=['POST'])
@login_required
@admin_required
def enviar():
    canal = request.form.get('canal', 'sms')
    telefone = request.form.get('telefone', '').strip()
    dias_str = request.form.get('dias', '60')

    if not telefone:
        flash('Informe um número de telefone.', 'danger')
        return redirect(url_for('notificacoes.painel'))

    try:
        dias = int(dias_str)
    except ValueError:
        dias = 60

    telefone_limpo = '+' + ''.join(c for c in telefone if c.isdigit() or c == '+')
    if not telefone_limpo.startswith('+'):
        telefone_limpo = '+55' + telefone_limpo.lstrip('+')

    if canal == 'whatsapp':
        resultado = enviar_whatsapp(telefone_limpo, dias)
    else:
        resultado = enviar_sms(telefone_limpo, dias)

    if resultado['ok']:
        if resultado.get('enviado'):
            registrar_log('Notificação Enviada', f'{canal.upper()} enviado para {telefone_limpo} — {resultado["mensagem"]}')
            flash(resultado['mensagem'], 'success')
        else:
            flash(resultado['mensagem'], 'info')
    else:
        flash(resultado['mensagem'], 'danger')

    return redirect(url_for('notificacoes.painel'))
